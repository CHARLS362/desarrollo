package carlos_david.turpo_ccama.loginscreen.activity.file.utils

const val   emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+"

